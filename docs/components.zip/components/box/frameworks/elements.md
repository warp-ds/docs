### Import

```js
import '@warp-ds/elements/components/box';

```

### Syntax

```js
<w-box info>
    <p>This is <strong>info</strong> variant of the box component</p>
</w-box>
```

### Props

<api-table type=elements component="Box" />