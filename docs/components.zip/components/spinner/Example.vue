<script setup>
</script>

<template>
  <div class="component py-32 px-16 flex gap-32 place-content-center place-items-center">
    <div class="animate-spinner [--spinner-size:16px]"></div>
    <div class="animate-spinner"></div>
    <div class="animate-spinner [--spinner-size:32px]"></div>
  </div>
</template>
