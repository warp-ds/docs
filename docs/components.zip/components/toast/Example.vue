<template>
  <div class="component space-y-16">
    <div>
      <h3 class="h4">Success</h3>
      <img src="/components/toast_success.png" alt="toast success" width="200"/>
    </div>
    <div>
      <h3 class="h4">Warning</h3>
      <img src="/components/toast_warning.png" alt="toast warning" width="200"/>
    </div>
    <div>
      <h3 class="h4">Error</h3>
      <img src="/components/toast_error.png" alt="toast error" width="200"/>
    </div>
  </div>
</template>