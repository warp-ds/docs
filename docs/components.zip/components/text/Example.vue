<script setup>
  import { ref } from "vue";

</script>

<template>
  <div class="component space-y-16">
    <div>
      <p class="text-display">Display</p>
    </div>
    <div>
      <p class="t1">Title1</p>
    </div>
    <div>
      <p class="t2">Title2</p>
    </div>
    <div>
      <p class="t3">Title3</p>
    </div>
    <div>
      <p class="t4">Title4</p>
    </div>
    <div>
      <p class="t5">Title5</p>
    </div>
    <div>
      <p class="t6">Title6</p>
    </div>
    <div>
      <p class="text-preamble">Preamble</p>
    </div>
    <div>
      <p class="text-body">Body</p>
    </div>
    <div>
      <p class="text-body font-bold">BodyStrong</p>
    </div>
    <div>
      <p class="text-caption">Caption</p>
    </div>
    <div>
      <p class="text-caption font-bold">CaptionStrong</p>
    </div>
    <div>
      <p class="text-detail">Detail</p>
    </div>
    <div>
      <p class="text-detail font-bold">DetailStrong</p>
    </div>
    
  </div>
</template>