<script setup>
import Overview from './overview.md';
import Usage from './usage.md';
import Styling from './styling.md';
import Dev from './code.md';
import Accessibility from './accessibility.md';
import data from './data.json';
import { mapFrameworkStatuses } from '../utils.js';
</script>

[Component ingress]

Related components: [Text field](../textfield/index.md)

## Example
<ThemeSwitcher />
[Component example]

## Anatomy
