### wClickable
When this component is placed into a Box or Card, it will make the entire component clickable.

### wDeadToggle
This component provides the UI of a toggle, but will not accept clicks or other interaction.

