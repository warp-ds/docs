### Accessibility

When using page indicators, be mindful of the background colour that will be used behind them. If there is a chance the contrast between the indicators and the background is too low, then place the indicators below, and outside of the content container. 