import React from "react";
import { PageIndicator } from "@warp-ds/components/react/pageindicator";

export default function PageIndicatorExample() {
	return <PageIndicator pageCount={5} selectedPage={1} />;
}
