### Import

```js
import '@warp-ds/elements/components/broadcast';

```

### Syntax

```html
<w-broadcast 
  api="https://dev.finn.no/broadcasts"
  url="https:/dev.finn.no/meldinger" interval="30000">
</w-broadcast>
```

### Props

<api-table type="elements" component="Broadcast" />